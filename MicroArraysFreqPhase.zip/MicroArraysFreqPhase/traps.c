/******************************************************************************/
/* Files to Include                                                           */
/******************************************************************************/

/* Device header file */
#if defined(__XC16__)
    #include <xc.h>
#elif defined(__C30__)
    #if defined(__dsPIC33E__)
    	#include <p33Exxxx.h>
    #elif defined(__dsPIC33F__)
    	#include <p33Fxxxx.h>
    #endif
#endif

#include <stdint.h>        /* Includes uint16_t definition */
#include <stdbool.h>       /* Includes true/false definition */
#include "cdefs.h"
#include "serialDriver.h"


/******************************************************************************/
/* Trap Function Prototypes                                                   */
/******************************************************************************/

/* <Other function prototypes for debugging trap code may be inserted here>   */

/* Use if INTCON2 ALTIVT=1 */
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void);
void __attribute__((interrupt,no_auto_psv)) _AddressError(void);
void __attribute__((interrupt,no_auto_psv)) _StackError(void);
void __attribute__((interrupt,no_auto_psv)) _MathError(void);

static void printErrorCode(INT32 errNo);

#if defined(__HAS_DMA__)

void __attribute__((interrupt,no_auto_psv)) _DMACError(void);

#endif

#if defined(__dsPIC33F__)

/* Use if INTCON2 ALTIVT=0 */
void __attribute__((interrupt,no_auto_psv)) _AltOscillatorFail(void);
void __attribute__((interrupt,no_auto_psv)) _AltAddressError(void);
void __attribute__((interrupt,no_auto_psv)) _AltStackError(void);
void __attribute__((interrupt,no_auto_psv)) _AltMathError(void);

    #if defined(__HAS_DMA__)

    void __attribute__((interrupt,no_auto_psv)) _AltDMACError(void);

    #endif

#endif

/* Default interrupt handler */
void __attribute__((interrupt,no_auto_psv)) _DefaultInterrupt(void);

#if defined(__dsPIC33E__)

/* These are additional traps in the 33E family.  Refer to the PIC33E
migration guide.  There are no Alternate Vectors in the 33E family. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void);
void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void);

#endif

/******************************************************************************/
/* Trap Handling                                                              */
/*                                                                            */
/* These trap routines simply ensure that the device continuously loops       */
/* within each routine.  Users who actually experience one of these traps     */
/* can add code to handle the error.  Some basic examples for trap code,      */
/* including assembly routines that process trap sources, are available at    */
/* www.microchip.com/codeexamples                                             */
/******************************************************************************/
#define ERROR_BASE    (100U)
#define ERR_OSC_FAIL  (ERROR_BASE + 1U)
#define ERR_ADDRESS   (ERROR_BASE + 2U)
#define ERR_STACK     (ERROR_BASE + 3U)
#define ERR_MATH      (ERROR_BASE + 4U)
#define ERR_DMA       (ERROR_BASE + 5U)
#define ERR_HARD      (ERROR_BASE + 6U)
#define ERR_SOFT      (ERROR_BASE + 7U)
#define ERR_DEFAULT   (ERROR_BASE + 8U)

/* Primary (non-alternate) address error trap function declarations */
void __attribute__((interrupt,no_auto_psv)) _OscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        /* Clear the trap flag */
        printErrorCode(ERR_OSC_FAIL);
        while(1);
}

void __attribute__((interrupt,no_auto_psv)) _AddressError(void)
{
        INTCON1bits.ADDRERR = 0;        /* Clear the trap flag */
        printErrorCode(ERR_ADDRESS);
        while (1);
}
void __attribute__((interrupt,no_auto_psv)) _StackError(void)
{
        INTCON1bits.STKERR = 0;         /* Clear the trap flag */
        printErrorCode(ERR_STACK);
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _MathError(void)
{
        INTCON1bits.MATHERR = 0;        /* Clear the trap flag */
        printErrorCode(ERR_MATH);
        while (1);
}

#if defined(__HAS_DMA__)

void __attribute__((interrupt,no_auto_psv)) _DMACError(void)
{
        INTCON1bits.DMACERR = 0;        /* Clear the trap flag */
        printErrorCode(ERR_DMA);
        while (1);
}

#endif

#if defined(__dsPIC33F__)

/* Alternate address error trap function declarations */
void __attribute__((interrupt,no_auto_psv)) _AltOscillatorFail(void)
{
        INTCON1bits.OSCFAIL = 0;        /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltAddressError(void)
{
        INTCON1bits.ADDRERR = 0;        /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltStackError(void)
{
        INTCON1bits.STKERR = 0;         /* Clear the trap flag */
        while (1);
}

void __attribute__((interrupt,no_auto_psv)) _AltMathError(void)
{
        INTCON1bits.MATHERR = 0;        /* Clear the trap flag */
        while (1);
}

    #if defined(__HAS_DMA__)

    void __attribute__((interrupt,no_auto_psv)) _AltDMACError(void)
    {
         INTCON1bits.DMACERR = 0;        /* Clear the trap flag */
         while (1);
    }

    #endif

#endif

/******************************************************************************/
/* Default Interrupt Handler                                                  */
/*                                                                            */
/* This executes when an interrupt occurs for an interrupt source with an     */
/* improperly defined or undefined interrupt handling routine.                */
/******************************************************************************/
void __attribute__((interrupt,no_auto_psv)) _DefaultInterrupt(void)
{
    printErrorCode(ERR_DEFAULT);
    while(1);
}

#if defined(__dsPIC33E__)

/* These traps are new to the dsPIC33E family.  Refer to the device Interrupt
chapter of the FRM to understand trap priority. */
void __attribute__((interrupt,no_auto_psv)) _HardTrapError(void)
{
    printErrorCode(ERR_HARD);
    while(1);
}
void __attribute__((interrupt,no_auto_psv)) _SoftTrapError(void)
{
    printErrorCode(ERR_SOFT);
    while(1);
}

static void printErrorCode(INT32 errNo)
{
    writeString("Exception:");
    writeNumber(errNo);
    writeString("\n");
}

#endif
